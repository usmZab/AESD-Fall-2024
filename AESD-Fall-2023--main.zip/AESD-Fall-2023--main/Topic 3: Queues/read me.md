## Creation of Queues in FreeRTOS
This is a sample code for demonstrating use of Queues by using FreeRTOS's port for ESP32 MCU.

Note that it uses **xQueueCreate()** API.

Please see the sample code.
 

