## Use of Mutex in FreeRTOS
This is a sample code for demonstrating use of MUTEX in FreeRTOS's port for ESP32 MCU.


Please see the sample code.
 


