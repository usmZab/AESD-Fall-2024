## Passing a data-structure to a Queue
This is a sample code for Passing a data-structure to a Queue on the ESP32 MCU by using FreeRTOS's port for ESP32.


Interesting execution behaviours are observed by commenting out **vTaskDelay()** API, one by one, from the tasks.

