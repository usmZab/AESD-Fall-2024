## Deferred Interrupt Processing (DIP) on ESP32 by using FreeRTOS

This example is quite interesting as it shows:
1. DIP, 
2. Producer-consumer model using Critical-Section directives to protect the shared variables, and
3. hardware timer configuration on ESP.

