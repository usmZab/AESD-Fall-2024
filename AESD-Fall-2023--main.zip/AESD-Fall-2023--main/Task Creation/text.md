## Task Creation
This is a sample code for creating a new Task for the ESP32 MCU by using FreeRTOS's port for ESP32.


Note that it uses **xTaskCreatePinnedToCore()** API, as we have the option of pinning this new task to a specific core of the dual-core ESP32.

Please see the sample code.
 
